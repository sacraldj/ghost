import Auth from '@/components/Auth'

export default function AuthPage() {
  return <Auth />
}
