/** @type {import('next').NextConfig} */
const nextConfig = {
  // Минимальная конфигурация для Next.js 15
}

module.exports = nextConfig 